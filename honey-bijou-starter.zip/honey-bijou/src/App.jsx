// (No se usa; la página principal es HoneyBijouPage)
export default function App(){ return null }
