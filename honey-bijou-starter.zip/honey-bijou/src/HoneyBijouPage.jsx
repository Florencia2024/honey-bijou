"use client";
import React, { useMemo, useState } from "react";
import {
  Search,
  Filter,
  Instagram,
  Star,
  Menu,
} from "lucide-react";

const BRAND = "Honey Bijou";

const BASE_PRODUCTS = [
  {
    id: "p1",
    name: "Collar Minimal Dorado",
    price: 12000,
    category: "Collares",
    color: "Dorado",
    rating: 4.8,
    image:
      "https://images.unsplash.com/photo-1617038260897-3d7f6b0da5e6?q=80&w=1400&auto=format&fit=crop",
    tags: ["acero quirúrgico", "hipoalergénico"],
    new: true,
  },
  {
    id: "p2",
    name: "Aros Perla Fresh",
    price: 8500,
    category: "Aros",
    color: "Perla",
    rating: 4.6,
    image:
      "https://images.unsplash.com/photo-1611746872915-64382b5b59f1?q=80&w=1400&auto=format&fit=crop",
    tags: ["clásico", "elegante"],
  },
  {
    id: "p3",
    name: "Pulsera Eslabón Fino",
    price: 6900,
    category: "Pulseras",
    color: "Plateado",
    rating: 4.6,
    image:
      "https://images.unsplash.com/photo-1603569283847-1f6c979f9c72?q=80&w=1400&auto=format&fit=crop",
    tags: ["plata 925"],
  },
];

const CATEGORIES = ["Todos", "Collares", "Aros", "Pulseras", "Anillos", "Tobilleras", "Sets"];

function peso(n) {
  return n.toLocaleString("es-AR", { style: "currency", currency: "ARS" });
}

export default function HoneyBijouPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Todos");
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(999999);
  const [sort, setSort] = useState("relevance");

  const products = BASE_PRODUCTS;

  const filtered = useMemo(() => {
    let list = products.filter((p) => p.name.toLowerCase().includes(query.toLowerCase().trim()));
    if (category !== "Todos") list = list.filter((p) => p.category === category);
    list = list.filter((p) => p.price >= (minPrice || 0) && p.price <= (maxPrice || Infinity));

    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list = [...list].sort((a, b) => b.rating - a.rating);
        break;
      case "new":
        list = [...list].sort((a, b) => (b.new ? 1 : 0) - (a.new ? 1 : 0));
        break;
      default:
        break;
    }
    return list;
  }, [products, query, category, minPrice, maxPrice, sort]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-amber-100/40 text-neutral-800">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/90 border-b">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden p-2 rounded-xl hover:bg-amber-100"
              aria-label="Abrir menú"
              onClick={() => setMenuOpen((s) => !s)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <a href="#" className="font-black tracking-tight text-xl sm:text-2xl text-amber-700">
              {BRAND}
            </a>
          </div>

          <div className="hidden lg:flex items-center gap-6 text-sm">
            {CATEGORIES.slice(1).map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1.5 rounded-full transition border ${
                  category === c
                    ? "bg-amber-500 text-white border-amber-500"
                    : "hover:bg-amber-50 border-transparent"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-amber-50">
            <Search className="w-4 h-4 opacity-70" />
            <input
              placeholder="Buscar…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="bg-transparent outline-none text-sm w-56"
            />
          </div>
        </div>

        {menuOpen && (
          <div className="lg:hidden border-t bg-white">
            <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 overflow-x-auto">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setCategory(c);
                    setMenuOpen(false);
                  }}
                  className={`px-3 py-1.5 rounded-full text-sm border ${
                    category === c
                      ? "bg-amber-500 text-white border-amber-500"
                      : "hover:bg-amber-50 border-neutral-200"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <section className="border-y bg-white/70">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-amber-50 flex-1 min-w-[220px]">
            <Search className="w-4 h-4 opacity-70" />
            <input
              placeholder="Buscar por nombre…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="bg-transparent outline-none text-sm w-full"
            />
          </div>

          <div className="flex items-center gap-2 text-sm">
            <Filter className="w-4 h-4" />
            <select
              className="px-3 py-2 rounded-xl border bg-white"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <input
              type="number"
              min={0}
              placeholder="$ min"
              value={minPrice}
              onChange={(e) => setMinPrice(Number(e.target.value))}
              className="w-24 px-3 py-2 rounded-xl border"
            />
            <input
              type="number"
              min={0}
              placeholder="$ max"
              value={maxPrice === 999999 ? "" : maxPrice}
              onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : 999999)}
              className="w-24 px-3 py-2 rounded-xl border"
            />
            <select
              className="px-3 py-2 rounded-xl border bg-white"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
            >
              <option value="relevance">Orden recomendado</option>
              <option value="price-asc">Precio: menor a mayor</option>
              <option value="price-desc">Precio: mayor a menor</option>
              <option value="rating">Mejor valoración</option>
              <option value="new">Novedades</option>
            </select>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <section className="relative">
          <div className="grid md:grid-cols-2 gap-8 items-center pb-8">
            <div>
              <h1 className="text-4xl font-extrabold tracking-tight text-amber-700">Honey Bijou</h1>
              <p className="mt-3 text-neutral-700 max-w-prose">
                Joyas dulces, hipoalergénicas y resistentes al agua. Envíos a todo el país.
              </p>
            </div>
            <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-lg">
              <img
                src="https://images.unsplash.com/photo-1603569283847-1f6c979f9c72?q=80&w=1400&auto=format&fit=crop"
                alt="Bijouterie hero"
                className="w-full h-full object-cover"
                loading="eager"
              />
            </div>
          </div>
        </section>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-lg">No encontramos resultados 😢</p>
            <p className="text-neutral-600">Probá con otro término o quitá filtros.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {filtered.map((p) => (
              <article key={p.id} className="group rounded-2xl overflow-hidden bg-white border hover:shadow-md transition">
                <div className="relative aspect-[4/5] overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition"
                    loading="lazy"
                  />
                  {p.new && (
                    <span className="absolute top-3 left-3 text-xs bg-amber-500 text-white px-2 py-1 rounded-full shadow">
                      Nuevo
                    </span>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-semibold leading-tight line-clamp-2 min-h-[2.5rem]">{p.name}</h3>
                  <div className="mt-1 text-sm text-neutral-600">{p.category} · {p.color}</div>
                  <div className="mt-2 flex items-center gap-1 text-amber-500">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`w-4 h-4 ${i < Math.round(p.rating) ? "fill-current" : "opacity-30"}`} />
                    ))}
                    <span className="text-xs text-neutral-600 ml-1">{p.rating.toFixed(1)}</span>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="font-bold text-lg text-amber-700">{peso(p.price)}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        <section className="mt-14">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xl font-bold text-amber-700">Seguinos en Instagram</h2>
            <a
              href="#"
              className="inline-flex items-center gap-2 text-sm hover:underline"
              title="Abrir Instagram"
            >
              <Instagram className="w-4 h-4" /> @{BRAND.toLowerCase().replaceAll(" ", "")}
            </a>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="aspect-square rounded-xl overflow-hidden">
                <img
                  src={`https://images.unsplash.com/photo-16${n}036592879-6e1667c3f2a2?q=80&w=600&auto=format&fit=crop`}
                  alt="Post de Instagram"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
