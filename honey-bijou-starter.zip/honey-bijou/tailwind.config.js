/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Quicksand', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        honey: {
          50:  '#fff7e6',
          100: '#ffefcc',
          200: '#fde3a7',
          300: '#f8cf6a',
          400: '#f0b429',
          500: '#e49b0f',
          600: '#c7810a',
          700: '#99630b',
          800: '#7a4e0d',
          900: '#5f3d0e',
        }
      }
    },
  },
  plugins: [],
}
