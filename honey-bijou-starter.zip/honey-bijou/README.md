# Honey Bijou — Starter (Vite + React + Tailwind)

Proyecto listo para publicar en Vercel. Incluye la página de catálogo sin carrito/newsletter/footer.

## Cómo usar
1) Instalar dependencias:
```bash
npm install
```

2) Ejecutar en local:
```bash
npm run dev
```

3) Editar productos en `src/HoneyBijouPage.jsx` (array `BASE_PRODUCTS`).

4) Subir a GitHub y desplegar en Vercel:
- New Project → Import Git Repository → Elegir este repo.
- Vercel detecta Vite automáticamente (`npm run build`, output `dist/`).

## Tipografía
Fuente por defecto: **Quicksand** (se puede cambiar desde `index.html` y `tailwind.config.js`).

---
© Honey Bijou
